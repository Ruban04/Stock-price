import express from 'express';
import axios from 'axios';

const app = express();
const port = 9876;
const WINDOW_SIZE = 10;

interface NumberResponse {
  numbers: number[];
}

interface AverageResponse {
  windowPrevState: number[];
  windowCurrState: number[];
  numbers: number[];
  avg: number;
}

class AverageCalculator {
  private window: number[] = [];
  private readonly windowSize: number;

  constructor(windowSize: number) {
    this.windowSize = windowSize;
  }

  public getWindow(): number[] {
    return [...this.window];
  }

  public addNumbers(numbers: number[]): void {
    // Add new numbers to the window
    this.window.push(...numbers);

    // If window exceeds size, remove oldest numbers
    if (this.window.length > this.windowSize) {
      this.window = this.window.slice(-this.windowSize);
    }
  }

  public calculateAverage(): number {
    if (this.window.length === 0) return 0;
    const sum = this.window.reduce((acc, num) => acc + num, 0);
    return Number((sum / this.window.length).toFixed(2));
  }
}

const calculator = new AverageCalculator(WINDOW_SIZE);

app.get('/numbers/:type', async (req, res) => {
  try {
    const { type } = req.params;
    const validTypes = ['p', 'f', 'e', 'r'];
    
    if (!validTypes.includes(type)) {
      return res.status(400).json({ error: 'Invalid number type' });
    }

    // Map type to API endpoint
    const typeMap: { [key: string]: string } = {
      'p': 'primes',
      'f': 'fibo',
      'e': 'even',
      'r': 'rand'
    };

    // Fetch numbers from the test server
    const response = await axios.get<NumberResponse>(
      `http://20.244.56.144/evaluation-service/${typeMap[type]}`
    );

    const prevWindow = calculator.getWindow();
    calculator.addNumbers(response.data.numbers);
    const currentWindow = calculator.getWindow();

    const result: AverageResponse = {
      windowPrevState: prevWindow,
      windowCurrState: currentWindow,
      numbers: response.data.numbers,
      avg: calculator.calculateAverage()
    };

    res.json(result);
  } catch (error) {
    console.error('Error:', error);
    res.status(500).json({ error: 'Internal server error' });
  }
});

app.listen(port, () => {
  console.log(`Server running at http://localhost:${port}`);
}); 